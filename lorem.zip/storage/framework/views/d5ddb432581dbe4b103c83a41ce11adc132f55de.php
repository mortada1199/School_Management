<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="<?php echo e(url('/')); ?>" class="logo logo-dark">
            
        </a>

        <a href="<?php echo e(url('/')); ?>" class="logo logo-light">

    </div>

    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>

    <div data-simplebar class="sidebar-menu-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu"
                style="

                padding-right: 0;
                margin-right: 0;">
                <li class="menu-title">القائمة</li>
                
                <li>

                    <a href="<?php echo e(url('/')); ?>">
                        <i class="uil-clinic-medical"></i>
                        <span> لوحةالتحكم</span>
                    </a>
                </li>
                


                <li class="menu-title"> نظام إداره المدرسة</li>

                <li>
                    

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-heart-medical"></i>
                        <span>
                            الطلبات
                        </span>
                    </a>
                    

                    <ul>

                        <li>
                            <a href="<?php echo e(route('orders.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    كل الطلبات
                                </span>
                            </a>
                        </li>
                        








                        

                    </ul>
                </li>
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                            الحصص
                        </span>
                    </a>
                    <ul>
                        <li>
                            
                            <a href="<?php echo e(route('Classes.create')); ?>">
                                <i class="uil-user-arrows"></i>
                                <span>
                                    اضافه الحصص
                                </span>
                            </a>
                            

                        </li>


                    </ul>
                </li>
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                            الدرجات
                        </span>
                    </a>
                    <ul>
                        <li>
                            
                            <a href="<?php echo e(route('grades.create')); ?>">
                                <i class="uil-user-arrows"></i>
                                <span>
                                    اضافه الدرجات
                                </span>
                            </a>
                            

                        </li>


                    </ul>
                </li>

                
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>   الفصول

                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('chapters.create')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    إنشاء فصل
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('chapters.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    الفصول
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>  التعليقات

                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('comments.index')); ?>">
                                <i class="uil-user"></i>
                                <span>
                                    التعليقات والتقييم
                                </span>
                            </a>
                        </li>


                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                             الإشعارات
                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="#">
                                <i class="uil-heart-rate"></i>
                                <span>
                                   الاشعارات
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    سجل زيادة الدم
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                



                




                <li>

                <li>
                    
                    <a href="#">
                        <i class="uil-file"></i>

                        <span>
                            التقارير
                        </span>
                    </a>
                    

                </li>
                
                </li>

            </ul>
        </div>

        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH /home/walieldin-nctr/Desktop/School_Management/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>