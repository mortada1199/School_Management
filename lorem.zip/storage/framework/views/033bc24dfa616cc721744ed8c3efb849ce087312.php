<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('translation.show_driver'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
           تفاصيل الفصل
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            تفاصيل الفصل

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
               المعلومات الاساسيه

                </div>
                <div class="card-body">
                    <table class="table table-hover">

                        <tbody>
                        <tr>

                            <td> الفصل</td>
                            <td><?php echo e($chapter->name); ?></td>

                        </tr>
                        <tr>
                            <td>الحصص</td>
                            <?php $__currentLoopData = $chapter->getMedia('classes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td><?php echo e($media->name); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center space-x-2">
                                        <a href="<?php echo e(route('chapters.downloadfile', $media->id)); ?>"
                                           class="text-gray-500 focus:outline-none hover:text-indigo-500">
                                            <button class="btn-primary">تنزيل</button>
                                        </a>
                                        <a href="<?php echo e(route('chapters.deletefile', [$media->id, $chapter->id])); ?>"
                                           class="text-gray-500 focus:outline-none hover:text-indigo-500">
                                            <button class="btn-danger">حذف</button>
                                        </a>
                                    </div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tr>
                        <tr>
                            <td>النتائج</td>

                            <?php $__currentLoopData = $chapter->getMedia('grades'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <td><?php echo e($media->name); ?></td>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center space-x-2">
                                        <a href="<?php echo e(route('chapters.downloadfile', $media->id)); ?>"
                                           class="text-gray-500 focus:outline-none hover:text-indigo-500">
                                            <button class="btn-primary">تنزيل</button>
                                        </a>
                                        <a href="<?php echo e(route('chapters.deletefile', [$media->id, $chapter->id])); ?>"
                                           class="text-gray-500 focus:outline-none hover:text-indigo-500">
                                            <button class="btn-danger">حذف</button>
                                        </a>
                                    </div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr>
                            <td>تاريخ الإنشاء</td>
                            <td><?php echo e($chapter->created_at->format('y-m-d')); ?></td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/School_Management/resources/views/chapters/show.blade.php ENDPATH**/ ?>