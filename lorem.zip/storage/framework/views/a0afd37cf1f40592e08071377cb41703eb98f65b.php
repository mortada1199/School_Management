<div class="dropdown d-inline-block">
    <a type="button" class="btn btn-outline-primary" id="page-header-user-dropdown" data-bs-toggle="dropdown"
       aria-haspopup="true" aria-expanded="false">
        <i class="uil-ellipsis-v d-none d-xl-inline-block font-size-1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end">

        <a class="dropdown-item" href="#" data-bs-toggle="modal"
           data-bs-target="#myModal-block-product-<?php echo e($comment->id); ?>">
             الرد علي التعليق </a>

        <a class="dropdown-item"
           onclick="event.preventDefault(); document.getElementById('profile-activate-<?php echo e($comment->id); ?>').submit();"
           href="#">
            <span class="align-middle"> حذف التعليق</span>
        </a>
        <?php if($comment->status=="الانتظار"): ?>

        <a class="dropdown-item" href="#" data-bs-toggle="modal"
           data-bs-target="#myModal-block-lorem-<?php echo e($comment->id); ?>">
            تعديل الحالة </a>
        <?php else: ?>
            <a class="dropdown-item" href="#"
               data-bs-target="#myModal-block-lorem-<?php echo e($comment->id); ?>" style=" cursor: not-allowed;color: grey"  >
                تعديل الحالة </a>

        <?php endif; ?>



    </div>
</div>





<form id="profile-activate-<?php echo e($comment->id); ?>" action="<?php echo e(route('comments.destroy', $comment)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<div id="myModal-block-product-<?php echo e($comment->id); ?>" class="modal fade" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel">     الرد علي التعليق  </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate action="<?php echo e(route("comments.update",$comment)); ?>" method="POST">
                <div class="row">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label for="result">   الرد   </label>

                            <input type="text" name="replay" class="form-control" >

                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div>
                <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>

                </form>
            </div>

        </div>
    </div>
</div>

<div id="myModal-block-lorem-<?php echo e($comment->id); ?>" class="modal fade" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel">تعديل </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate
                      action="<?php echo e(route('updateStatus', $comment->id)); ?>" method="POST" >
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="col-md-12">


                            <div class="mb-3">
                                <label for="status">اختار</label>
                                <select name="status" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="الانتظار">الانتظار</option>
                                    <option value="مكتمل">مكتمل</option>

                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e(__($message)); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div>
                    <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/walieldin-nctr/Desktop/School_Management/resources/views/partials/comment-options.blade.php ENDPATH**/ ?>